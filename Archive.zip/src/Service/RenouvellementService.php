<?php

namespace App\Service;

use App\Repository\ProfessionnelRepository;
use App\Repository\TransactionRepository;
use App\Repository\UserRepository;
use Doctrine\ORM\EntityManagerInterface;

class RenouvellementService
{
    private TransactionRepository $repoTransaction;
    private ProfessionnelRepository $repoProfessionnel;
    private EntityManagerInterface $entityManager;
    private UserRepository $userRepository;

    private $sendMailService;
    

    public function __construct(
        TransactionRepository $transactionRepository,
        ProfessionnelRepository $repoProfessionnel,
        EntityManagerInterface $entityManager,
        UserRepository $userRepository,
        SendMailService $sendMailService,
    ) {
        $this->repoTransaction = $transactionRepository;
        $this->repoProfessionnel = $repoProfessionnel;
        $this->entityManager = $entityManager;
        $this->userRepository = $userRepository;
        $this->sendMailService = $sendMailService;
    }

    public function updateData(): string
    {
        $now = new \DateTime();
        $compteur = 0;

        // Étape 1 : récupérer les professionnels dont le statut ≠ renouvellement
        $professionnels = $this->repoProfessionnel->createQueryBuilder('p')
            ->where('p.status != :statut')
            ->setParameter('status', 'renouvellement')
            ->getQuery()
            ->getResult();

        foreach ($professionnels as $pro) {

        
            // je recupere le user 
            $user = $this->userRepository->findOneBy(['personne' => $pro->getId()]);


            // Étape 2 : dernière transaction
            $lastTransaction = $this->repoTransaction->createQueryBuilder('t')
                ->where('t.user = :user')
                ->andWhere('t.state = :state')
                ->setParameter('user', $user)
                ->setParameter('state', 1)
                ->orderBy('t.createdAt', 'DESC')
                ->setMaxResults(1)
                ->getQuery()
                ->getOneOrNullResult();

            if ($lastTransaction) {
                $dateTransaction = $lastTransaction->getCreatedAt(); 

                $now = new \DateTime();
                $diff = $dateTransaction->diff($now);

                // Étape 3 : si date > 1 an
                if ($diff->y >= 1) {
                    $pro->setStatus('renouvellement'); 
                    $this->entityManager->persist($pro);


                    $user_message = [
                        'message' => "Bonjour " .$user->getEmail() .",votre abonnement à expiré ,si vous souhaitez le renouveller veillez vous connecter à votre dashboard pour le faire",
    
                    ];
    
                    $context = compact('user_message');
    
                    // TO DO
                    $this->sendMailService->send(
                        'tester@myonmci.ci',
                        $user->getEmail(),
                        'Informations',
                        'renew_mail',
                        $context
                    );
                    $compteur++;
                }

            }
        }

        $this->entityManager->flush();

        return "$compteur professionnels ont été mis à jour pour renouvellement.";
    }
}
